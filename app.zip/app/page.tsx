'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

type Song = { id: string; title: string; artist: string; platform: 'youtube'|'spotify'|'soundcloud'; url: string; cover_url: string|null; release_date: string|null; created_at: string };

function embedUrl(song: Song) {
  try {
    const u = new URL(song.url);
    if (song.platform === 'youtube') {
      const id = u.hostname.includes('youtu.be') ? u.pathname.slice(1) : u.searchParams.get('v') || u.pathname.split('/').filter(Boolean).pop();
      return id ? `https://www.youtube-nocookie.com/embed/${id}` : null;
    }
    if (song.platform === 'spotify') {
      const parts = u.pathname.split('/').filter(Boolean);
      const idx = parts.findIndex(x => ['track','album','playlist','episode'].includes(x));
      return idx >= 0 && parts[idx+1] ? `https://open.spotify.com/embed/${parts[idx]}/${parts[idx+1]}` : null;
    }
    if (song.platform === 'soundcloud') return `https://w.soundcloud.com/player/?url=${encodeURIComponent(song.url)}&color=%238b5cf6&auto_play=false&hide_related=true`;
  } catch { return null; }
  return null;
}

export default function Home() {
  const [songs, setSongs] = useState<Song[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      if (!supabase) { setLoading(false); return; }
      const { data } = await supabase.from('songs').select('*').eq('published', true).order('created_at', { ascending: false });
      setSongs((data as Song[]) || []);
      setLoading(false);
    }
    load();
  }, []);

  return <main>
    <nav className="nav"><a className="brand" href="#top">SADAT <span>BEIGH</span></a><div><a href="#music">Music</a><a href="#about">About</a><a className="admin-link" href="/admin">Admin ↗</a></div></nav>
    <section className="hero" id="top">
      <div className="hero-glow" />
      <p className="eyebrow">INDEPENDENT ARTIST · KASHMIR</p>
      <h1>Music that<br/><em>speaks.</em></h1>
      <p className="hero-copy">A sound, a story, a feeling.<br/>Explore the latest releases by Sadat Beigh.</p>
      <a className="primary" href="#music">Explore music <span>↓</span></a>
      <div className="hero-note">SADAT BEIGH <span>— OFFICIAL MUSIC</span></div>
    </section>
    <section className="music-section" id="music">
      <div className="section-head"><div><p className="eyebrow">THE SOUND</p><h2>Latest <em>releases</em></h2></div><span className="count">{songs.length.toString().padStart(2,'0')} TRACKS</span></div>
      {!supabase && <div className="notice">Connect Supabase using the setup guide to display your music.</div>}
      {loading ? <p className="muted">Loading music…</p> : songs.length === 0 ? <div className="empty"><span>♪</span><h3>No releases yet.</h3><p>New music will appear here when it’s published.</p></div> : <div className="song-grid">{songs.map(song => {
        const embed = embedUrl(song);
        return <article className="song-card" key={song.id}>
          <div className="cover">{song.cover_url ? <img src={song.cover_url} alt={`${song.title} cover`} /> : <div className="cover-placeholder"><span>SB</span><small>SADAT BEIGH</small></div>}<span className="platform">{song.platform.toUpperCase()}</span></div>
          <div className="song-info"><div><h3>{song.title}</h3><p>{song.artist}</p></div>{song.release_date && <time>{new Date(song.release_date+'T00:00:00').toLocaleDateString('en',{day:'2-digit',month:'short',year:'numeric'})}</time>}</div>
          {embed ? <iframe className="player" src={embed} title={`${song.title} music player`} allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy" /> : <a className="listen" href={song.url} target="_blank" rel="noreferrer">Listen ↗</a>}
        </article>;
      })}</div>}
    </section>
    <section className="about" id="about"><p className="eyebrow">THE ARTIST</p><h2>Stories in sound.<br/><em>Feelings in rhythm.</em></h2><p>Independent music by Sadat Beigh. Follow the journey, one release at a time.</p><div className="socials"><a href="https://instagram.com/" target="_blank" rel="noreferrer">Instagram ↗</a><a href="https://youtube.com/" target="_blank" rel="noreferrer">YouTube ↗</a></div></section>
    <footer><span>© {new Date().getFullYear()} SADAT BEIGH</span><span>MADE FOR THE MUSIC.</span><a href="/admin">Admin login ↗</a></footer>
  </main>;
}
